Tento parametr umožňuje hráči jezdit na entitě.

Můžete také povolit možnost ovládání.