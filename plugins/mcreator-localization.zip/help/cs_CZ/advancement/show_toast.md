Ukázat pokrok v pravém horním rohu obrazovky když hráč dokončí pokrok.
