Pokrok po kterém váš pokrok bude zobrazen.

Při použití "Žádný rodič: kořen" vytvoří novou kategorii.