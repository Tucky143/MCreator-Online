Toto je typ pokroku

* Úkol je základní typ pokroku a je nejběžnější.
* Cíl je dlouhodobý cíl, o který hráč usiluje.
* Výzva je pro otestování nebo vyzvání hráče k něčemu.