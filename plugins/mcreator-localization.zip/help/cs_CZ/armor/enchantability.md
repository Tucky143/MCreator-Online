Jak vzácné bude očarování na toto brnění dostávat. Čím vyšší očarovanost, tím lepší očarování brnění bude dostávat.

Hodnoty ve Vanille:

* Kožené brnění: 15
* Kroužkové brnění: 12
* Železné brnění: 9
* Zlaté brnění: 25
* Diamantové brnění: 10
* Netheritové brnění: 15