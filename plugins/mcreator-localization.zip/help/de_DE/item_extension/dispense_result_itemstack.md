Dieses Verfahren bestimmt, was mit dem Artikel geschieht, nachdem er versucht wurde. Wenn nichts ausgewählt ist oder die gewählte Prozedur keinen Gegenstandstapel zurückgibt, der aktuelle Gegenstand wird im Falle eines Verzichts auf Erfolg um 1 verkleinert.

Du kannst diese Prozedur benutzen, um den Gegenstand zu konsumieren, ihn zu beschädigen oder durch einen anderen Gegenstand ersetzen.