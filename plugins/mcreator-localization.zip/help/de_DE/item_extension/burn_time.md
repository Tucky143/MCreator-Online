Brennzeit zeigt an, wie viele Ticks ein gegebener Brennstoff halten wird.

Kohle dauert 80 Sekunden, um vollständig zu verbrennen und so ist es 1600 Ticks. (Die Standardeinstellung) Dies reicht aus, um 8 Elemente zu schmelzen, was bedeutet, dass 20 Ticks eine Sekunde der Brennzeit sind.

Um zu messen, wie viele Ticks Sie verwenden müssen, verwenden Sie diese Gleichung:

`Anzahl der benötigten Ticks = #von Gegenständen, die der Brennstoff schmelzen soll * 200`

Klicke [hier](https://mcreator.net/wiki/burn-time-fuels) für eine Liste der Brennzeiten der häufig verwendeten Gegenstände für das Schmelzen in Minecraft.

