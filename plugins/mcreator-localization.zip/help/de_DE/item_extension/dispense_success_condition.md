Diese Bedingung bestimmt, ob der Spender beendet ist. Wenn die Bedingung fehlschlägt, spielt der Spender den Fehlschlag.

Der Wert dieser Prozedur wird an "${l10n.t("elementgui.item_extension.dispense_result_itemstack")}" als "Erfolgreiche" Abhängigkeit übergeben.