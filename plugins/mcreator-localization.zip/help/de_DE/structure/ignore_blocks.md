Diese Option legt fest, welche Blöcke beim Generieren der Struktur nicht platziert werden sollen (ignorieren).

Wählen Sie hier Luft aus, um keine Luftblöcke Ihrer Struktur zu platzieren. Dadurch wird die Struktur besser in die Umwelt integriert aber im Falle von höhlenbasierten Strukturen werden Sie wahrscheinlich auch die Luft platzieren wollen.