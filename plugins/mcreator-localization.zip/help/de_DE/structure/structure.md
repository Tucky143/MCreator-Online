Aktuelles Vanillelimit für eine einzelne Struktur beträgt 48x48x48 Blöcke, aus Performance-Gründen.

Strukturblock ist ein eingebauter Vanilleblock, der Builds als .NBT-Strukturen speichern kann.

Du kannst strukturelle Leerzeichen verwenden, um zu erlauben, dass andere Blöcke Luftblöcke in deiner Struktur überschreiben, wenn sie generiert werden. Zum Beispiel wenn Sie möchten, dass Ihre Struktur nach innen begraben wird, können Sie die innerhalb der Struktur mit Leerzeichen mit dem Befehl /fill füllen, damit natürliche Blöcke spawnen können, wo sich die Leerräume befinden. Leerzeichen werden in deinen Strukturen nicht generieren. Sie sind nur Platzhalterblöcke, damit andere Blöcke den Bereich während der Erzeugung überschreiben.