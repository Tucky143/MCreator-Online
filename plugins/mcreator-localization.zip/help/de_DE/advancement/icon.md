Das Symbol, das auf der Fortschrittsregisterkarte angezeigt wird.

Handelt es sich um den ersten Fortschritt, dann ist es auch das Symbol für die Fortschrittsregisterkarte.

Hier werden nur Gegenstände unterstützt. Blöcke ohne Gegenstände können nicht als Symbol angezeigt werden.