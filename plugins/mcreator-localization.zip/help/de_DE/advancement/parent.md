Nach diesem eingestellten Fortschritt wird der Fortschritt aufgelistet.

Du kannst "No parent: root" verwenden, um einen neuen Pfad zu erstellen (neue Fortschrittsregisterkarte).