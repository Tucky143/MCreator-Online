Dies ist die Art des Fortschritts

* "Aufgabe" ist eine normale Fortschrittsart, die am häufigsten vorkommt. (eckiger Rahmen)
* "Ziel" ist eine langfristige Aufgabe. (runder Rahmen)
* "Herausforderungen" sind besonders schwer zu erreichende Fortschritte. Wenn eine Herausforderungen erledigt ist, ertönt ein Gong. (gezackter Rahmen)