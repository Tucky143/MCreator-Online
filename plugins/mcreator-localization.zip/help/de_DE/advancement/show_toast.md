Zeige den Fortschritt oben rechts auf dem Bildschirm, wenn der Spieler den Fortschritt abschließt.
