Diese Bedingung bestimmt, ob der Effekt seine Tick-Prozedur aktivieren soll, basierend auf der Stufe und der verbleibenden Dauer.

Verwende diese Bedingung um Effekte zu erzeugen, die sich wie Regeneration oder Gift. Eine Prozedurvorlage dafür ist auch verfügbar.