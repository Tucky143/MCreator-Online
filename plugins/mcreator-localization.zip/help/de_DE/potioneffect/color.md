Wählen Sie die Farbe der Flaschen und den Pfeil.

Sie benötigen diese Option nicht, wenn Sie die Elemente nicht wollen.