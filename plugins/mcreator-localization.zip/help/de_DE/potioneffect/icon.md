Dieser Parameter steuert das Symbol, das im Inventar des Spielers angezeigt wird, wenn der Trank aktiv ist.

WICHTIG: Wenn sich der Name der Textur vom Registry-Namen des Elements unterscheidet, wird eine Kopie der Textur erstellt.