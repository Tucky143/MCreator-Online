Wenn diese Option aktiviert ist, wird ein fester Farbton auf den Block angewendet, während er im Inventar ist, passend zum Farbtyp.

Der Farbton wird auch dann angewandt, wenn eine Objekttextur angegeben ist.