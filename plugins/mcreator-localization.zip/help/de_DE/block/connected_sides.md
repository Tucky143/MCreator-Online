Dieser Parameter sollte nur in Kombination mit transparenten Blöcken verwendet werden.

Dadurch werden die inneren Seiten des Blocks ähnlich wie Glas, Eis und ähnliche Blöcke miteinander verbunden.