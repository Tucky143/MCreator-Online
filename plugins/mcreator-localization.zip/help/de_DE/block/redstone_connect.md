Wenn dieser Parameter aktiviert ist, wird sich der Redstone-Staub immer mit in Verbindung setzen (ähnlich wie die Redstone-Blöcke).

HINWEIS: Der Block kann immer noch Redstone-Kraft emittieren, auch wenn dieser Parameter nicht aktiviert ist.