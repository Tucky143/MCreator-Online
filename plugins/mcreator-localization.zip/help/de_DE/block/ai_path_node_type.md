Dieser Parameter bestimmt, wie der Block von den KI-Pfadnavigatoren der Monster "gesehen" wird.

Verschiedene KI-Pfadknotentypen führen zu unterschiedlichen Entscheidungen darüber, wie mit der Bewegung verfahren werden soll, wenn in der Nähe von Block, abhängig vom KI-Pfadknotentyp.