Hier kannst du Animationen angeben, die diese Block-Entität abspielen kann und die Bedingungen, wenn Animationen passieren.

**Vergewissere dich, dass Animationen, die du verwendest, nur Modellpartikel/Knochen referenzieren, die in der Modelldatei vorhanden sind.
Andernfalls kann das Modell nicht geladen werden oder das Spiel könnte abstürzen.**

Wir empfehlen die Verwendung von NBT-Daten zur Bereitstellung von Daten für Animationsbedingungen da die Bedingung nur client-seitig
ist, aber die Daten für das Schalten von Animationen sind normalerweise keine Client-Seite.

Bestehende Modellanimationen, die in der Modelldatei oder beim Import der Modelldatei angegeben sind, werden neben den hier angegebenen Animationen auch
abspielen.