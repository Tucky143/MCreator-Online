Dieser Parameter steuert die Sprunghöhe von Entitäten

Standardwert, der von den meisten Blöcken verwendet wird, ist 1,0. Der Honig-Blocksprungfaktor ist 0,5.