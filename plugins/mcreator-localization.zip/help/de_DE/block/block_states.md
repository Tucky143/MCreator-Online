Hier kannst du zusätzliche benutzerdefinierte Eigenschaften dieses Blocks auflisten.
Blockeigenschaften definieren grundlegende mögliche Zustände des Blocks.

Je mehr Eigenschaftskombinationen möglich sind, desto langsamer wird das Spiel geladen und betrieben.
Wenn Sie viele Zustände definieren müssen, sollten Sie stattdessen NBT-Daten verwenden.

Einige Eigenschaften werden intern verwendet (für Blockrotation, Wasserprotokollierung und Blockbasen), sodass ihre Namen nicht verwendet werden können.

Neben benutzerdefinierten Einstellungen kannst du auch vordefinierte Blockzustandseigenschaften von Vanilla Minecraft-Blöcken einfügen.