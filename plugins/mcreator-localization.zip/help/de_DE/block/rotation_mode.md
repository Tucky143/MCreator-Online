* **Keine Drehung:** Blockausrichtung.
* **Y-Achsen-Rotation (S/W/N/E):** Dreht nur die Seiten basierend auf der Art und Weise, in der der Spieler steht.
* **D/U/N/S/W/E Drehung:** Dreht alle Seiten basierend auf der Art und Weise, wie der Spieler sieht.
* **Y-Achsen-Drehung (S/W/N/E):** Dreht nur die Seiten basierend auf der Blockseite, auf die der Block geklickt wird.
* **D/U/N/S/W/E Drehung:** Dreht alle Seiten basierend auf der Blockfläche, auf die der Block geklickt wird.
* **Log-Rotation (X/Y/Z):** Dreht den Block wie Vanillelogs.