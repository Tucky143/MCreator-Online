Dies ist der Ton, der gespielt wird, wenn der Spieler den Block abbaut.

HINWEIS: Dieser Ton wird in Schleife abgespielt, während er zerbricht, bis der Block kaputt ist.