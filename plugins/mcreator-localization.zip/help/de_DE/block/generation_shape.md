Die Generationsform erlaubt es je nach Höhe des Blocks zu ändern, wie der Block erzeugt wird.

* **Uniform**: Dies ist ein einfaches Rechteck. Dies war die Form, die vor Minecraft 1.18 verwendet wurde.
* **Dreieck**: Diese Form erzeugt den Block wie ein Dreieck. Die Ebene mit der größten Wahrscheinlichkeit diesen Block zu erhalten, ist die Mitte der minimalen und maximalen Höhe. Bitte beachten Sie, dass die maximale und minimale Generationshöhe über und unterhalb der Weltgrenzen liegen kann.