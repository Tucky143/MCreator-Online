Dieser Parameter steuert die Geschwindigkeit von Entitäten in diesem Block.

Standardwert, der von den meisten Blöcken verwendet wird, ist 1,0. Der Seelensand und die Honigblockgeschwindigkeit sind 0,4.