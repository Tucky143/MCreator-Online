Dieser Parameter legt fest, wie der Block mit einem Kolben reagiert.

* Normal: Normale Reaktion von Kolben wie dem Stein
* Zerstören: Wenn der Block von einem Kolben gedrückt wird, wird der Block zerstört.
* Block: Der Block reagiert nicht auf einen Kolben wie den Obsidian.
* Nur Push: Der Block kann nur durch einen Kolben geschoben werden.