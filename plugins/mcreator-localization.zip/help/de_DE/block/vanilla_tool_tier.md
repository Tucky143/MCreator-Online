Dies ist die Stufe des Werkzeugs, das benötigt wird, um diesen Block abzubauen.

Nur Werkzeuge mit der festgelegten Stufen, können diesen block abbauen.

Wenn du genauere Kontrolle wie selbst erstellte Stufen brauchst, verwende eigenen Prozeduren für die Abbaubedingungen.