Wenn Redstone-Parameter aktiviert ist, können Sie mit diesem Parameter die emittierte Redstone-Kraft ändern.

Wenn dies eine bedingte Prozedur verwendet wird und eine Nummer zurückgibt die von diesem Block emittierte Redstone-Kraft wird durch die zurückgegebene Anzahl der Prozeduren gesetzt.

HINWEIS: Der Block kann immer noch Redstone emittieren, auch wenn sich der Rotstein nicht mit ihm verbindet.

WARNUNG: Wenn Sie benutzerdefinierte Nummernanbieterverfahren verwenden, müssen Sie benachbarte Blöcke mit Rotstone-Wert ändern, damit sie die Änderung registrieren können.