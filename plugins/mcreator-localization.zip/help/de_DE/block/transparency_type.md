**Aktivieren Sie dieses Kästchen, wenn Ihr Block Transparenz** - für einen festen Block deaktiviert lassen Überprüfen Sie, ob Ihr Block wie Blätter, Glas, Eisenstangen usw. ähnelt.

Transparenz-Typen:

* **Solid:** Keine Transparenz (ähnlich wie Erde, Stein, etc.)
* **Cutout:** Transparent ohne Mipmapping (ähnlich wie Glas)
* **Cutout mipped:** Wie Cutout, aber mit Mipmapping
* **Durchsichtig:** Teilweise transparent und die schwerste Option (ähnlich Eis)