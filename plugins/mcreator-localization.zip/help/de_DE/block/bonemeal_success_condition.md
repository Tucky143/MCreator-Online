Diese Bedingung bestimmt, ob die Verwendung von Knochenmehl auf diesem Block erfolgreich ist.

Wenn dies falsch ist, wird das Knochenmehl konsumiert, aber die "${l10n.t("elementgui.common.event_on_bonemeal_success")}" Prozedur wird nicht ausgeführt.