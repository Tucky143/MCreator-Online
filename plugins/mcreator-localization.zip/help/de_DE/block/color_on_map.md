Dies ist die Farbe, die Ihr Block auf den Karten anzeigt.

Wenn auf Standard gesetzt, basiert die Farbe auf dem Material des Blocks.

Um die exakten RGB-Farben aller Einträge zu sehen, lesen Sie die Wiki-Seite [hier](https://mcreator.net/wiki/list-block-map-colors).