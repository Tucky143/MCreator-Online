Dieser Parameter definiert ein benutzerdefiniertes Element oder Block, das fallen gelassen wird, wenn dieser Block abgebaut oder beschädigt ist.

Wenn das Ernteniveau verwendet wird, werden nur richtige Erntewerkzeuge den Blockabfall bewirken.