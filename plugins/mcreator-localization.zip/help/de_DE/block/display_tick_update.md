Löst eine Prozedur zufällig aus.

Dieser Trigger wird nur auf Client-Seite ausgelöst, so dass von hier aus keine echten Änderungen vorgenommen werden sollten, außer dass Klänge abspielt und Partikel platziert.