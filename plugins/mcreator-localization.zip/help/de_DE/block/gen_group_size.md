Dieser Parameter steuert die durchschnittliche Anzahl von Blöcken pro Erzader an.

Vanilla Erzgruppengröße:

* Kohleerz - 17
* Eisenerz - 9
* Golderz - 9
* Redstone-Erz - 8
* Diamanterz - 8
* Lapis Lazuli - 7