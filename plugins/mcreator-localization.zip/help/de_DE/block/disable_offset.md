Wenn der Block einen zufälligen Modellversatz aufweist, wird auch das Begrenzungsfeld verschoben, sofern diese Option nicht aktiviert ist. Wenn das Begrenzungsfeld wegen des Versatzes in benachbarte Blöcke eintaucht, aktivieren Sie dieses Kästchen, um dies zu verhindern.

Zum Beispiel wäre diese Option falsch für Bambus, und wahr für großes Gras.