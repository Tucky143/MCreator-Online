Diese Bedingung bestimmt, ob Knochenmehl überhaupt in diesem Block verwendet werden kann.

Wenn dies falsch ist, wird das Knochenmehl nicht konsumiert und nichts passiert.