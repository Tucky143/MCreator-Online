Legt die durchschnittliche Anzahl der Erzader fest, die pro Chunk spawnen sollen.

Vanilla Erzgruppe pro Chunk-Werte:

* Kohleerz - 20
* Eisenerz - 20
* Gold Erz - 2
* Redstone-Erz - 8
* Diamanterz - 1
* Lapis Lazuli - 1