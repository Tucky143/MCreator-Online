Wenn die Blockbasis verwendet wird, sind einige Parameter aufgrund des Basisblocks möglicherweise deaktiviert oder funktionieren möglicherweise nicht Sie erfordern Standardwerte aus dem Basisblock.

Benutzen Sie diesen Parameter nur, wenn es einen guten Grund dafür gibt. Die meisten Blöcke sollten diesen Standard-Baustein auf Standard setzen.