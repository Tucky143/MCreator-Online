Dieser Parameter bestimmt, wie oft der Block tickt. Wenn zufällig markiert ist, hat dieser Parameter keine Wirkung.

Beachten Sie, dass normalerweise automatisch generierte Blöcke standardmäßig nicht markiert werden, es sei denn, dass zufällig verwendet wird.

Standard-Tick-Rate von 0 bedeutet, dass der Block nicht automatisch markiert wird.

Wenn dieser Parameter auf eine Zahl größer als 0 gesetzt ist, wird der Block automatisch markiert. Es gibt 20 Welt-Ticks in einer Sekunde.