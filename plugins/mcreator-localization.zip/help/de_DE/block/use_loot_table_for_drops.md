Wenn diese Option aktiviert ist, wird der Block keine eigene Beutetabelle erstellen. Stattdessen, muss der Benutzer selber den Block-Drop definieren.

Erstellen Sie ein Mod-Element mit dem Registry-Namen `-Blocks/${registryname}`, Namensraum _Mod_und geben Sie _Block_ ein.

Beutetabellen können Block-Drops immer noch überschreiben, selbst wenn diese Option aktiviert ist.