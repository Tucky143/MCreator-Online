Dieser Parameter gibt eine zusätzliche Bedingung an, die in der Reihenfolge für die Automatisierung
erfüllt werden muss (Behälter, Automatisierungsmodi von Drittanbietern), um
Gegenstände aus dem ausgewählten Slot dieses Blocks zu nehmen.

Diese Bedingung wird zusammen mit einer Liste von Slots überprüft, die das Einnehmen von Artikeln erlauben, sodass beide Bedingungen erfüllt werden müssen.