Dieser Parameter wird deinem Block ein Inventar geben. Der Block wird eine Kachel sein.

Dieser Parameter ermöglicht Funktionen wie:
* NBT-Tags im Block
* Inventar für die Artikelspeicherung des Blocks
* Vergleichs-Interaktion

Diese Funktionen werden ohne die Überprüfung dieses Parameters nicht funktionieren.