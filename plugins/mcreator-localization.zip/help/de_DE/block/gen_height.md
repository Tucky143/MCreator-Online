Dieser Parameter steuert den Y-Höhenbereich, in dem dieser Block generieren kann.

Höhen der Vanilla-Generation:
* Kohleerz - 0 bis 256
* Kupfererz - -16 bis 112
* Eisenerz - -32 bis 256
* Gold Erz - -64 bis 32
* Redstone Erz - -64 bis -32
* Diamanterz - -64 bis 16
* Smaragd-Erz - -16 bis 256
* Lapis Lazuli - -64 to 64