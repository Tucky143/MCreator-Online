Dieser Parameter bestimmt, ob die Blockplatzierung zufällig versetzt werden soll und um welche Achse.

Die meisten Anlagen verwenden eine der Offsettypen.