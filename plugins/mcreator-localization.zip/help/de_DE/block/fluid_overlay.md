Dieser Parameter sollte nur in Kombination mit transparenten Blöcken verwendet werden.

Wenn diese Option aktiviert ist, zeigt der Block die Flüssigkeitstextur nicht an, wenn er überschwemmt wird, ähnlich wie Glasblöcke.