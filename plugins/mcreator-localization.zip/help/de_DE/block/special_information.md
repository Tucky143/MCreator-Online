Dieser Parameter fügt einen Tooltip zum Block hinzu, wenn du dein Symbol über den Block in deinem Inventar hältst.

Wenn du einen Prozeduren-generierten Tooltip verwendest und dein Block ist nicht von einer Entität oder aktuell einer gedroppten Element-Entität gehalten, wird die `Entität`-Abhängigkeit null sein.