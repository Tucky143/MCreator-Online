Dieser Parameter bestimmt, wie glatt der Block ist.

Standardwert, der von den meisten Blöcken verwendet wird, ist 0.6