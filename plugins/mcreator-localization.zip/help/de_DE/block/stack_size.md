Dies ist, wie viele Gegenstände im Inventar dieses Blocks auch stapeln können.

Beachten Sie, dass es für die einzelnen Artikel ein anderes Limit für die Stapelgröße gibt, so dass dies eine Obergrenze der Slots ist, die durch Artikel weiter eingeschränkt werden können.