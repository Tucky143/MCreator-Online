Dieser Parameter steuert den Power-Bonus, den der Block für die verzaubernde Tabelle hat.

Der Power-Bonus des Bücherregals ist 1, der normalen Blöcke, es ist 0.