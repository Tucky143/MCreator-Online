Dieser Parameter steuert die maximale Größe des Stapels, der in seinen internen Inventarplätzen platziert werden kann.

Beachten Sie, dass die kleinere Zahl zwischen diesem Parameter und der maximalen Größe des Stapels die tatsächliche maximale Stapelgröße bestimmt.