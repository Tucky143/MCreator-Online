Verwende diesen Auslöser, um zusätzliche Erntebedingungen anzugeben.
Sowohl Vanilla als auch benutzerdefinierte Erntebedingungen müssen erfüllt sein, um den Block zu ernten.

Wenn diese Prozedur falsch zurückgibt, wird der Block nicht geerntet.