Aktivieren Sie diesen Parameter, wenn Sie möchten, dass die Elemente fallen, wenn der Block defekt ist.

Truhen verwenden diesen Parameter, zum Beispiel.