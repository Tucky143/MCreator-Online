Wenn dieser Parameter aktiviert ist, ist dieser Block empfindlich auf Vibrationen wie _Sculk Sensor_.

HINWEIS: Block-Entität muss aktiviert sein, damit dies funktioniert.