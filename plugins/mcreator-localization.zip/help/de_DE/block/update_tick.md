Löst eine Prozedur aus, wenn der Block angekreuzt wird.

Natürlich markieren die gespawnten Blöcke nur, wenn zufällige Tickings aus Leistungsgründen verwendet werden.
