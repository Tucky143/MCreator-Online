Dieser Parameter legt fest, ob der Spieler ihn abbauen kann.

Vanilla Beispiele: Bedrock und Befehlsblock