Liste der Blöcke, die dieser Block bei der Erzeugung ersetzen kann.

Wenn Sie diese Liste leer lassen, wird der Block nicht auf natürliche Weise generiert, da dies nicht möglich ist sich auf die Welt zu stellen.