Wenn Sie diesen Parameter überprüfen, der Spieler kann einen weiteren Block darauf platzieren (dieser Block kann durch andere Blöcke ersetzt werden).

Beispiele: Luft, die meisten Pflanzen