Die automatisch generierten Blöcke werden normalerweise nicht standardmäßig Ticken, es sei denn, dass zufällig markiert wird.

Dieser Parameter macht Block-Ticks zufällig, wobei die Geschwindigkeit durch einen globalen Welt-Ticket Parameter gesteuert wird.

Diese Art von Ticking wird zum Beispiel von Pflanzen verwendet.