Dieser Parameter gibt eine zusätzliche Bedingung an, die in der Reihenfolge für die Automatisierung erfüllt werden muss (Behälter, Automatisierungsmodi von Drittanbietern), um
Gegenstände in den ausgewählten Bereich dieses Blocks platzieren zu können.

Diese Bedingung wird zusammen mit einer Liste von Slots überprüft, die das Einfügen von Artikeln ermöglichen, sodass beide Bedingungen erfüllt werden müssen.