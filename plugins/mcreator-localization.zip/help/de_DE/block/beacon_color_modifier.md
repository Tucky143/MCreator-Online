Wählen Sie die Farbe, die Ihr Block auf den Leuchtturm anwenden wird (wie das rote Glas, Orangenglas usw.).

Überlassen Sie DEFAULT, um Vanillehandling zu behalten (keine Farbänderung).