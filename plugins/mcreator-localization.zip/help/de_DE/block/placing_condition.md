Diese Bedingung bestimmt, ob dieser Block an einem bestimmten Ort platziert werden kann. Wenn die Position nicht mehr gültig ist, wird der Block beschädigt, sobald er eine Blockaktualisierung erhält.

HINWEIS: Diese Bedingung ist während der Weltgenerierung nicht überprüft.
