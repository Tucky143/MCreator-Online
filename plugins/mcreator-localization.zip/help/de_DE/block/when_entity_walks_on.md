Löst eine Prozedur aus, wenn eine Entität oben auf diesem Block geht.

Es wird nicht aufgerufen, wenn die Entität schleicht.

Diese Einstellung funktioniert nur bei Blöcken mit voller Höhe. Sie wird nicht funktionieren mit Stufen, Druckplatten, etc.

Für solche Fälle, sollten "collide trigger" benutzt werden.