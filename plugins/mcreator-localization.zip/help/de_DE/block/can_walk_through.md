Wenn dieser Parameter aktiviert ist, kann der Spieler ihn durchlaufen, wie das hohe Gras und die Ranken.

Block wird ein Begrenzungsfeld haben, aber es wird nicht kollidierbar sein.