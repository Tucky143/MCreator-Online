Wenn aktiviert, können Entitäten auf dem Block klettern.

Die Breite und Tiefe des Blocks muss kleiner als 1 sein, damit dieser Parameter funktioniert damit die Kollisionen im Block richtig erkannt werden. Ändern Sie die Umrandungsbox, wenn dieser Parameter verwendet wird.

Vanilla Beispiele: Leiter und Reben