Überprüfen Sie diesen Parameter, wenn Ihr Block:

* ist kein fester Würfel / hat eigene Form,
* oder transparente Teile der Textur.

Wenn Sie dieses Häkchen aktivieren, wird der Block:

* keine redstone Power durchführen
* haben occlusion deaktiviert,
* haben die visuelle Umrandungsbox auf leer gesetzt.