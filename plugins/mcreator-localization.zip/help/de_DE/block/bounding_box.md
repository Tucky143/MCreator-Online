Die Blockabmessungen und die Begrenzungsbox legen die Hitbox für den Block fest, wenn er ein benutzerdefiniertes Modell ist. Es kann auch eine normale Blockgröße von einem Würfel auf andere Dimensionen ändern, wenn kein benutzerdefiniertes Modell verwendet wird.

Dies setzt jedoch nur die Dimensionen, nicht die Form.

Um zu verstehen, wie Umrandungsparameter funktionieren, klicken Sie [hier](https://mcreator.net/wiki/block-dimensions-and-bonding-box).