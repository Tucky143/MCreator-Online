Dieser Parameter legt fest, wie schnell der Block durch Feuer verbraucht wird.

Vanilla examples:
* logs haben eine Flammfähigkeit von 5
* bretter haben eine Brennbarkeit von 20