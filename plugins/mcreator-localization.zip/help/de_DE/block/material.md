Block-Material definiert einige Basisblockeigenschaften wie die Reaktion auf Kolben, Wasser, Anbauoptionen und vieles mehr.

Wenn du den Block für Erz verwenden möchtest, wähle ROCK Material damit das Ernteniveau korrekt angewendet wird.

Klicke [hier](https://mcreator.net/wiki/materials) um mehr über Materialien zu erfahren.