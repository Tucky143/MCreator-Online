Legt fest, welche Art von Werten von dieser Blockeigenschaften akzeptiert werden kann:

- **Logik:** _true_ oder _false_
- **Integer:** Integer-Zahlen im Bereich vom angegebenen Minimalwert bis zum angegebenen Maximalwert
- **Enum:** Einer der aufgelisteten Textwerte