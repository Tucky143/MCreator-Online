Diese optionale Eigenschaft ändert die Textur des Blocks im Inventar.

Wird üblicherweise mit Türen oder kundenspezifischen Modellen verwendet.