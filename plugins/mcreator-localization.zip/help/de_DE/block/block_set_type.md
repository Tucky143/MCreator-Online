Dieser Parameter steuert Töne und Verhalten einiger Blockbasen:

- **Button**: Holzknöpfe können durch Pfeile ausgelöst werden und länger gedrückt bleiben.
- **Zaun**: Holzzäune und nicht hölzerne Zäune verbinden sich nicht.
- **Druckplatten**: Holzdruckplatten können von jeder Kreatur, nicht nur von Mobs und Spielern, ausgelöst werden.
- **Tür/Falltür**: Eisentüren und Falltüren können nicht von Hand geöffnet werden.