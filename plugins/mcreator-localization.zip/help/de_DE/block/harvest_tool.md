Dieser Parameter legt fest, welches Werkzeug Sie den Block abbauen möchten.

Erze nuttzen hier die Spitzhacke, Axt für Holz und Schaufel für Erde.

Wenn auf "Nicht spezifiziert" gesetzt, können Spieler diesen Block mit der Hand unterbrechen.
