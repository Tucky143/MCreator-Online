Dieser Parameter bestimmt, wie viele Slots dein Block für sein internes Inventar verwenden wird.

Wenn der Block an die GUI gebunden ist, setze diesen Wert auf `die größte Slot-ID in der GUI + 1`