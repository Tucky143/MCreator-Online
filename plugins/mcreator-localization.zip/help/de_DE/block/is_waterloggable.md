Wenn aktiviert, ist Wasser innerhalb des Blocks platzierbar.

Vanilla Beispiele: Platten, Treppen usw.
