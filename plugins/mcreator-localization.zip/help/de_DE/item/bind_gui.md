Wählen Sie hier Ihre GUI aus, um das Inventar und die GUI-Bindung für diesen Gegenstand zu aktivieren.

Auf Leer setzen, um das Inventar zu deaktivieren (Sie wollen dies in den meisten Fällen).

Das Aktivieren des Inventars macht dieses Item unstapelbar.