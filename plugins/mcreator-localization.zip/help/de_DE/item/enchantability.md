Wie häufig seltene Verzauberungen mit diesem Gegenstand/Werkzeug verzaubert werden können. Je höher die Verzauberung, desto besser werden Sie beim Verzaubern des Gegenstands/Werkzeugs bekommen.

Vanilla Werte:

* Holzwerkzeuge: 15
* Steinwerkzeuge: 5
* Eisenwerkzeuge: 14
* Goldwerkzeuge: 22
* Diamantwerkzeuge: 10
* Netherit-Werkzeuge: 15
* Bücher: 1