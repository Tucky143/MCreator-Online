Das Verfahren wird ausgeführt, wenn ein Spieler mit der rechten Maustaste auf diesen Gegenstand in seiner Hand klickt.

Wenn Sie möchten, dass diese Prozedur nur aufgerufen wird, wenn die Entität mit diesem Item in der Luft klickt, "${l10n. ("elementgui.common.event_right_clicked_block")}" sollte immer SUCCESS/CONSUME zurückgeben.