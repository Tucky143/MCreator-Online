Analoge Redstone-Werteausgabe des Vergleichs, wenn diese Musikdisc in der Jukebox daneben vorhanden ist.
