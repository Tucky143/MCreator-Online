Dieser Parameter legt fest, wie lange das Element auf einmal verwendet werden kann.

Wenn der Gegenstand ein Lebensmittel ist, legt dieser Wert die Zeit in Ticks fest, die der Spieler nimmt, um einen Gegenstand des Lebensmittels zu essen.