Die Seltenheit beeinflusst nur die Farbe des Namens des Gegenstands.
* Normal: Weiß
* Ungewöhnlich: Gelb
* Selten: Aqua
* Episch: Hellviolett