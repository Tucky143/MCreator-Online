Dieser Parameter kontrolliert den Namen dieser Eigenschaft. Doppelte Namen sind nicht erlaubt.

Es sind einige Eigenschaften für alle Items im Namen von Vanilla Minecraft definiert, so dass ihre Namen nicht verwendet werden können.