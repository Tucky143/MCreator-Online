Die Länge der Musik-Scheibe in Ticks.

Dieser Parameter wird verwendet, um Hilfsgeistern zu signalisieren, mit dem Tanzen aufzuhören, wenn die Anzahl der Ticks erreicht ist
Die in diesem Feld angegebene Zeit vergeht seit Beginn der Wiedergabe.
