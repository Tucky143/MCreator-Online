Wählen Sie die Anzahl der Slots, die Ihr GUI/Inventar hat. Vergessen Sie nicht, 1 der größten Slot-ID hinzuzufügen.

Wenn der Block an die GUI gebunden ist, setze diesen Wert auf `die größte Slot-ID in der GUI + 1`