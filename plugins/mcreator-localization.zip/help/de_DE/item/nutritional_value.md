Der Nährwert ist, wie viel dieses Lebensmittel dem Spieler nährt.

1 ist 1/2 in der Hungerleiste und 20 ist die vollständige Hungerleiste.