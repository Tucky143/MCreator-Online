Geben Sie eine Prozedur an, um den Wert dieser benutzerdefinierten Objekteigenschaft zu bestimmen.

Wenn eine Entität diesen Gegenstand hält, beschreiben die angegebenen Koordinaten/Welt den Ort dieser Entität.