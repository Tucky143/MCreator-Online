Diese Prozedur wird vor dem Fernkampf-Element aufgerufen, um zu überprüfen, ob der Rückgabewert der gewählten Prozedur wahr ist.

Behalte "${l10n.t("condition.common.true")}, um zusätzliche Bedingungen zu deaktivieren. Munitionsüberprüfungen gelten in diesem Fall noch immer.