Löst eine Prozedur aus, wenn die Einheit den Gegenstand in der Luft bewegt.

Zum Beispiel, wenn Sie mit der rechten Maustaste auf Ihr Element in der Luft klicken, wird die Prozedur ausgeführt.