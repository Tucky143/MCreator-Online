Wählen Sie das Modell, das mit diesem Element verwendet werden soll. Das Modell definiert nur das visuelle Aussehen.

* **Normal** - Normaler Gegenstand
* Werkzeug - Modell, das von Tools verwendet wird
* Benutzerdefiniert - Du kannst auch benutzerdefinierte JSON, JAVA und OBJ Modelle definieren

Bei der Erstellung benutzerdefinierter Modelle wird JSON aufgrund der Vanille-Unterstützung für diesen Modelltyp empfohlen.