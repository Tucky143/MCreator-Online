Zerstöre Geschwindigkeitsparameter bestimmt, wie schnell dieser Gegenstand die Blöcke zerstört.

Typische Werte:
* **1** - Normaler Artikel
* **1.5** Schwert
* **2>** Erntewerkzeug