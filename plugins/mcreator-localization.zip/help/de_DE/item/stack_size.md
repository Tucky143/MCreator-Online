Dies ist die maximale Anzahl an Gegenständen dieses Typs, die in einen Stapel passen können.

Vanilla-Beispiel: Enderperlen haben eine Stapelgröße von 16.