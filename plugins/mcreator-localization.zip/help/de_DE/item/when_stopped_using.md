Diese Prozedur wird aufgerufen, wenn der Spieler diesen Gegenstand nicht mehr benutzt (löst ihn mit der rechten Maustaste frei).

Dieser Trigger funktioniert nur, wenn die Benutzungsdauer des Gegenstands größer als 0 ist.