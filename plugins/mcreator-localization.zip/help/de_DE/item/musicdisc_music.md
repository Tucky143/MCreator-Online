Wählen Sie die Musik aus, die in der Jukebox abgespielt werden soll.

Um alle Jukebox-Funktionen zu unterstützen, z. B. dass der Ton mit zunehmender Entfernung leiser wird,
Stellen Sie sicher, dass Ihr Ton im MONO-Format vorliegt.

Wenn du die Mod weiterverteilen möchtest, stelle sicher, dass du die Berechtigung hast, die Musik
zu verteilen, die du verwendest!