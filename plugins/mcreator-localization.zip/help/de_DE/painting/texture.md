Wählen Sie eine Textur aus, die als Vordergrund.

WICHTIG: Wenn sich der Name der Textur vom Registry-Namen des Elements unterscheidet, wird eine Kopie der Textur erstellt.