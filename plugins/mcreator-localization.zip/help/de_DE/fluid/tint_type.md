Diese Option wirkt auf die Flüssigkeit basierend auf Biomfarben, ähnlich wie Gras, Blätter und Wasser. Für beste Ergebnisse, sollte die Flüssigkeit eine Graustufentextur verwenden.

Der Farbtyp wirkt sich auch auf die automatisch generierte Textur der Gruppe aus.