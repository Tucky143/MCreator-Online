Dieser Zustand bestimmt, ob sich die Flüssigkeit von einer bestimmten Position ausbreiten kann.

Beachten Sie, dass dies auch von anderen Eigenschaften beeinflusst ist (nahe Hänge, feste Blöcke etc.).