Dieser Parameter bestimmt, wie viele Ticks es dauert, bis sich die Flüssigkeit auf einen anderen Block ausbreitet. Je höher dieser Wert ist, desto langsamer bewegt sich die Flüssigkeit.

Die Standardwerte sind 5 für Wasser, 30 für Lava in der Overworld und 10 für Lava im Nether.