Dies ist die Temperatur deiner Flüssigkeit, gemessen in Kelvin. Je höher der Wert, desto wärmer wird deine Flüssigkeit sein.

Der Standardwert ist 300K, was in der Nähe der Raumtemperatur liegt.