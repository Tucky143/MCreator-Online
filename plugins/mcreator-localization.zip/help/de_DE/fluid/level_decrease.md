Dieser Parameter legt fest, wieviel der Wert dieses Flüssigkeitswertes für jeden Block, auf den er sich erstreckt, abnimmt. Mit höheren Werten, wird die Flüssigkeit einen kleineren Bereich decken.

Dieser Wert ist 1 für Wasser und Lava im Nether, 2 für Lava in der Überwelt.