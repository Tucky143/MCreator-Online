Aktivieren Sie diesen Parameter, um das Netherartige Portal für diese Dimension zu aktivieren.

Sie können dies deaktiviert lassen und Prozeduren verwenden, um benutzerdefinierte Weise für die Eingabe dieser Dimension zu definieren.