Die Prozedur wird ausgeführt, wenn ein Spieler die Dimension verlässt.
