Dieser Parameter regelt, wie stark das Umgebungslicht in dieser Dimension ist. Bei einem Wert von 1, sieht die Dimension so aus, als hätte der Spieler den Nachtsichteffekt.

Diese Option ist nur visuell und beeinflusst nicht die Spiellogik (z.B. Kreaturenspawns).

Vanilla Werte sind 0,1 im Nether und 0 in allen anderen Dimensionen.