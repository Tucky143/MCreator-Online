Wählen Sie diesen Parameter, um den integrierten Zünder zu verwenden. Deaktivieren Sie dies, wenn Sie planen, einen benutzerdefinierten Zünder zu verwenden.

Um einen benutzerdefinierten Zünder zu erstellen, erstellen Sie eine neue Prozedur, und verwenden Sie die eingebaute Vorlage 'Portal in eine Dimension mit benutzerdefiniertem Zündergegenstand'.