Die Liste an Biomen die in dieser Dimension generiert werden. Die Biome bestimme alle Eigenschaften der Dimensionsregionen wie Pflanzentypen, Bäume, Strukuturen und Mob-Spawning-Eigenschaften.

Die Dimension wird die Biome gleichmäßig und entsprechend der Biom-Eigenschaften verteilen.
