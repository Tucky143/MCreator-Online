Dieser Parameter lässt die Dimension in ähnlicher Weise Skylight haben wie Überwelt mit Tagesnächtzyklus.

Denken Sie daran, dass Skylight nicht durch Blöcke verbreitet wird, also werden die Nether Dimensionen mit Skylight immer noch dunkel sein und brauchen die globale Lichtquelle aktiviert, um nicht dunkel zu sein.