Dieser Parameter bestimmt, ob das Herstellungsrezept eine bestimmte Form haben muss.

Wenn aktiviert, wird jede Artikelkonfiguration mit diesen Elementen als Rezept akzeptiert.