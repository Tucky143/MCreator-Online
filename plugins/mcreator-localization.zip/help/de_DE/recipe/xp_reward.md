Dieser Parameter legt fest, wie viele Erfahrungspunkte der Spieler nach dem Abschließen des Rezepts erhält.

Dieser Parameter wird nur bei Kochrezepten verwendet.