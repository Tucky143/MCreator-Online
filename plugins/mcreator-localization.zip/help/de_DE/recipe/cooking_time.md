Dieser Parameter wird von Kochrezepten verwendet, um festzulegen, wie lange ein Gegenstand kochen wird.

Einheit sind Ticks, so dass für eine Sekunde der Kochzeit muss man die Kochzeit auf 20 Ticks setzen.