Dieser Parameter legt fest, in welchem Herstellungssystem dein Rezept verfügbar sein wird.

* Herstellen ist die Werkbank.
* Schmelzen ist Ofen-Rezept.
* Schmelzen ist ein Rezept innerhalb des Schmelzofens.
* Rauchen ist ein Rezept im Raucher.
* Steinsägen ist ein Steinsägen-Rezept.
* Lagerfeuerkochen ist ein Rezept, wenn wir mit der rechten Maustaste auf ein Lagerfeuer klicken.
* Schmieden ist ein Rezept im Schmiedetisch.
* Das Brauen ist ein Rezept in einem Brauständer.