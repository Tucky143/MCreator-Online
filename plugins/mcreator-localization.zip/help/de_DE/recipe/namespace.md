* Benutze "Mod" Namensraum, um ein neues Rezept für dein Mod/Datenpaket zu erstellen.
* Verwende "Minecraft", um Vanillerezepte zu überschreiben.