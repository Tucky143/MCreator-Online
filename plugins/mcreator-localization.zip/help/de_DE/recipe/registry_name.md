Die Rezept-ID Ihres Rezepts (Zum Beispiel: diamond_block).

Wenn du ein Vanille-Rezept überschreiben möchtest, Sie müssen den gleichen Namen wie der Vanille-Registry-Name des vorgegebenen Rezeptes in dieses Feld eingeben.