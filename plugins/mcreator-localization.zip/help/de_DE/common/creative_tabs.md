Diese Einstellung legt fest wo dein Mod im Kreativ-Modus-Inventar gefunden werden kann.

Falls diese Liste leer ist, wird der Mod nicht im Kreativ-Modus-Inventar zu finden sein.