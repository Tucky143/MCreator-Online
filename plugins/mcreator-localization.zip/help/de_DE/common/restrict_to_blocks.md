Benutze dieses Feld, um festzulegen, auf welchen Blöcke(n) das Spawnen stattfinden soll.

Wenn die Liste leer ist, wird diese Option deaktiviert und kann auf allen Blöcken spawnen.