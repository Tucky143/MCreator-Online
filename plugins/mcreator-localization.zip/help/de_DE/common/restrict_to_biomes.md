Benutze dieses Feld, um Biome zu definieren, wo das Spawnen stattfinden soll.

Wenn die Liste leer ist, wird keine Biombeschränkung gesetzt und das Spawnen tritt in allen Biomen auf.