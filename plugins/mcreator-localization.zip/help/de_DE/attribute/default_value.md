Dies ist der Standardwert des Attributes.
Das Attribut wird diesen Wert erhalten, bis etwas im Spiel (Prozedur, Kommando oder Modifikator) ihn verändert.
Der Wert eines Attributes ist die Zahl, die errechnet wird, nachdem Modifikatoren und min/max Beschränkungen auf den Grundwert angewendet wurden.