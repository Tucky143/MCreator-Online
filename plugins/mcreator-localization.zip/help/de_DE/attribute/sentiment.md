Dieser Parameter bestimmt, ob das Attribut als positiv, negativ oder neutral gesehen wird.
Dies ändert auch die Farbe der Modifikatoren dieses Attributes.