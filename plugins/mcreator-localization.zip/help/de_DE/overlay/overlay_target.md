Das Overlay-Ziel legt fest, auf welchem Bildschirm dieses Overlay gezeichnet werden soll.

Verwende Ingame für Overlays wie Hungerbarren und Kürbis-ähnliche Overlays.

Verwenden Sie andere Ziele, um andere spezifische Bildschirme zu überlagern.