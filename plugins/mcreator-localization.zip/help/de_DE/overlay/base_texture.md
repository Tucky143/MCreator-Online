Eine Basis-Textur für Ihr Overlay. Andere Komponenten werden über diese Textur gezeichnet.

Dieser Parameter kann verwendet werden, um "Kürbis" wie Overlays zu erzeugen.

Empfohlene Overlay-Größe ist 1920 x 1080 zu machen ist richtig skaliert.