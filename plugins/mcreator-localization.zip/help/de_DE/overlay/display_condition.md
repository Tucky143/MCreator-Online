Diese Prozedur legt fest, ob das Overlay angezeigt werden soll.

Wenn die Prozedur wahr ist, wird das Overlay auf dem Bildschirm angezeigt.