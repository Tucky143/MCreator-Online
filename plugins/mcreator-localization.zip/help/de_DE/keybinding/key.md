Dieser Parameter definiert den Schlüssel, der zur Ausführung der Tastenbelegung verwendet wird.

Spieler können es immer innerhalb der Steuerung ändern.