Diese Prozedur wird ausgeführt, wenn die ausgewählte Taste freigegeben wird (nachdem der Spieler die Taste gedrückt hat).

Sie können mittels Pressedms-Abhängigkeit bestimmen, wie lange die Taste in Ihren benutzerdefinierten Prozeduren gedrückt wurde.