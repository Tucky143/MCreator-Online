Aktivieren Sie diese Option, um die Speicherung von Flüssigkeiten zu aktivieren.

Blöcke müssen die Kacheleinheit aktiviert haben, damit das Flüssigkeitstanksystem ordnungsgemäß funktioniert.