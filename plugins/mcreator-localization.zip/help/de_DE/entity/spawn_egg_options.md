Wenn dieser Parameter aktiviert ist, wird die erste Farbe der Hintergrund des Ei sein. Die zweite Farbe wird die Kreise auf dem Ei sein.

Sie können auch die kreative Registerkarte für das Spawn-Ei wählen.