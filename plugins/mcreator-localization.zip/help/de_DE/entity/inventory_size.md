Dieser Parameter bestimmt, wie viele Slots deine Kreatur für sein internes Inventar verwenden wird.

Setze diesen Wert auf `die größte Slot-ID in der GUI + 1`.