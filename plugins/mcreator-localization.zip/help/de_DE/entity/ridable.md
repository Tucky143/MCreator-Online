Mit diesem Parameter kann der Spieler diese Einheit einbinden.

Sie können auch optionale Controller aktivieren.