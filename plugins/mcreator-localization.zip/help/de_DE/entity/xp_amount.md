Dieser Parameter steuert die Menge an Erfahrungen, die durch das Töten des Mobs gewonnen wurden.

Dieser Parameter ist normalerweise 1-3 für ein Tier und 5 für ein Monster.