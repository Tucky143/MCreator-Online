Der lebende Sound ist der Umgebungsklang, den die Entität zufällig abspielen wird.

Leer lassen um den Ambient Sound zu deaktivieren.