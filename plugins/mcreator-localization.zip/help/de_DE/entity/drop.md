Das Block/Gegenstand, das der Mob fällt, wenn er stirbt.

Alternativ können Sie auch Beutetabellen verwenden, um weitere Drops zu erhalten und die Seltenheit jedes Tropfens zu bestimmen.