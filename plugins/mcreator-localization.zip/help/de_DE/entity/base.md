Eine Vanilla Entität KI um eine Entität wie eine Vanilla zu machen.

Es wird auch einige Parameter wie die Drops überschreiben.

Normalerweise sollte dieser Parameter vermieden werden und bei der Voreinstellung bleiben.