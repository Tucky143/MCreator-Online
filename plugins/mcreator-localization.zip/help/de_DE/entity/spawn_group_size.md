Das hier angegebene Minimum und Maximum legen die Größe der Gruppen fest, in denen die Entität spawnen wird.

Beachten Sie, dass Entitäten in Gruppen von über 20 (seltener werden Gruppen spawnen).