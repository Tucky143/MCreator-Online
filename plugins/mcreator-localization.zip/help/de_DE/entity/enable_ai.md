Wenn aktiviert, werden die KI-Aufgaben für die Entität aktiviert.

KI-Aufgaben, die im KI-Task-Builder definiert sind, werden keine Wirkung haben, wenn dies nicht aktiviert ist.

Wenn Sie nicht irgendeine Art von Misc Entity tun, möchten Sie, dass dies aktiviert bleibt.