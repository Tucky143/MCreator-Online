Wenn aktiviert, wird Ihre Entität ein Boss sein.

Der Farbparameter steuert die Farbe der Bossleiste, ähnlich dem Balkenstil.