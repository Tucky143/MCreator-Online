Der Rückstoßwiderstand definiert den Widerstand gegen den Angriffsrückschlag der Entität. Im Allgemeinen verwenden die meisten Vanille-Entitäten sie nicht, aber als Referenz hat sie 0,5.
