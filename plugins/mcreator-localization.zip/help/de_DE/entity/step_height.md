Legt die Schritthöhe der Einheit fest.

Die meisten normalen Wohneinheiten haben eine Schritthöhe von 0,6, während Reittiere wie Pferde eine Schritthöhe von 1 haben.