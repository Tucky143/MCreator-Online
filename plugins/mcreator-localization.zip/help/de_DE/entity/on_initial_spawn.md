Löst die Prozedur aus, wenn die Entität spawnt.

Beachten Sie, dass einige Verfahrensblöcke in diesem Trigger während der frühen Welterzeugung möglicherweise nicht richtig funktionieren.