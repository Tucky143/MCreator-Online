Das Überprüfen dieses Parameters macht diese Entität zu einem fliegenden Entität.

Das bedeutet, es hat Flugwegsnavigator und Bewegungssteuerung und hat Schwerkraft und Fall Schaden deaktiviert.