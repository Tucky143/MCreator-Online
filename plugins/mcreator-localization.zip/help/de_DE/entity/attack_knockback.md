Der Angriffsknockback definiert den Rückstoßwert jedes Angriffs dieser Entität Die meisten Vanille-Entitäten verwenden ihn nicht. Einige tun es, wie der ravager, der einen Rückschlag von 1,5 hat.
