Um deine Entität zu spawnen wie die Vanille, musst du diese Option nicht ändern.

Wenn Sie jedoch benutzerdefinierte Laichbedingungen haben wollen, müssen Sie eine neue Bedingung anlegen.