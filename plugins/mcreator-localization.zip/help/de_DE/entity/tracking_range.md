Dieser Parameter legt fest, wie viele Blöcke weit die Entität von den Spielern verfolgt wird.

Die Einstellung dieses Parameters auf 0 deaktiviert die Darstellung und Kollisionen der Entität.