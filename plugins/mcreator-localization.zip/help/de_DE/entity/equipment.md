Erlaubt es dem Mob, Ausrüstung zu haben, wenn das Mob-Modell dies unterstützt.

Von links nach rechts repräsentieren die Slots die rechte Hand, dann die linke, dann den Kopf, die Brustplatte, Leggings und Stiefel.