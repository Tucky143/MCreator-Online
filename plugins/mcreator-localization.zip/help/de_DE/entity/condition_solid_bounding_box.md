Wenn diese Funktion aktiviert ist, wird die Begrenzungsbox der Entität ähnlich wie der Begrenzungsbox eines Blocks agieren (massive Kollision).

Gebraucht von Booten und Shulkern in Vanilla Minecraft.