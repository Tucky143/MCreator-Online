Dieser Parameter steuert die Priorität, die der Mob gegenüber anderen hat, wenn das Spiel auswählt, welcher Mob generiert werden soll.

Ein höheres Gewicht bedeutet, dass mehr Monster im Spiel diesen Mob erzeugen. Erstelle dies für Tiere im Vergleich zu Monstern.

Spawngewichtssystem ist ausführlich beschrieben [hier](https://mcreator.net/wiki/mob-spawning-parameters)