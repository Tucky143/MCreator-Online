Wenn diese Option aktiviert ist, verschwindet der Spieler, der sich weit genug bewegt (Standardverhalten für die meisten Mobs).

Schalte dies für Bosse und beschwörbare Mobs aus, um den Despawnenden zu stoppen.