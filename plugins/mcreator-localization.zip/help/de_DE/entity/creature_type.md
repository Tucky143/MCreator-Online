Erlaubt es dir, den Kreaturentyp zu setzen und bestimmte Änderungen zu bewirken.
* **Untote** erleidet zusätzlichen Schaden durch die Smite Verzauberung, werden durch Schaden geheilt und durch Heilung geschädigt, und werden nicht von Gift oder Regeneration beeinflusst.
* **Arthropods** erleidet zusätzlichen Schaden durch die Verzauberung der Arthropoden.
* **Illager** scheint keine Wirkung zu haben.
* **Wasser** erleidet zusätzlichen Schaden durch die Impellende Verzauberung. 