Dies ist eine Vorschau auf das weiße Muster, wenn es auf einem schwarzen Schild, mit der Vorderseite auf der linken Seite.

In den meisten Fällen sollte das Muster nur den schwarzen Teil der Vorderseite abdecken.