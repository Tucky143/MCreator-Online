Diese Textur wird verwendet, wenn das Muster auf ein Schild angewendet wird.

Die Textur sollte 64x64 sein und bezieht sich auf die weiße Variante (andere Farben werden automatisch vom Spiel generiert).

Schilder verwenden ein 12x22x1 kuboides Modell.