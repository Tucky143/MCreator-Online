Wenn diese Option ausgewählt ist, wird das Muster standardmäßig nicht in der Benutzeroberfläche des Webstuhls sichtbar.
Stattdessen wird ein Bannermuster-Element benötigt.

Benutzerdefinierte Gegenstände für Banner-Muster können mit dem Gegenstands-Mod-Element erstellt werden.