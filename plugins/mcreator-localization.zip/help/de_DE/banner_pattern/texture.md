Diese Textur wird verwendet, wenn das Muster auf ein Banner angewendet wird.

Die Textur sollte 64x64 sein und bezieht sich auf die weiße Variante (andere Farben werden automatisch vom Spiel generiert).

Banner verwenden ein 20x40x1 kuboides Modell.