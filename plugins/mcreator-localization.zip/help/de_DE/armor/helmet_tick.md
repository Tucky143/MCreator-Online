Wenn eine Entität den Helm ausgerüstet hat, wird jeder Tick ausgeführt.

Übergebene Entität ist die Entität die die Rüstung trägt, der übergebene Gegenstandstapel ist der Gegenstand der Rüstung.