Widerstandskraft ist ein Wert, der den Schutz der Rüstung erhöht.

Die Diamantrüstung hat eine Widerstandskraft von 2.0 (für insgesamt 8.) und die Netherrüstung haben eine Widerstandskraft von 3,0 (für insgesamt 12,0).