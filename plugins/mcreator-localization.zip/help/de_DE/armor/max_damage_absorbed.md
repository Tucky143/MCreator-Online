Dieser Parameter definiert die Haltbarkeit von Rüstungen und wird effektiv angewendet als:

* Helm: max_damage_absorbed * 11
* Harnisch: max_damage_absorbed * 16
* Beinschutz: max_damage_absorbed * 15
* Stiefel:  max_damage_absorbed * 13

Vanilla Rüstung verwendet folgende Faktoren:

* Lederrüstung: 5
* Kettenrüstung: 15
* Eisenrüstung: 15
* Goldrüstung: 7
* Diamantrüstung: 33
* Netheriterüstung: 37