Wie häufig seltene Verzauberungen auf dieser Rüstung gemacht werden können. Je höher die Verzauberbarkeit, desto bessere Verzauberungen erhältst du, wenn du die Rüstung verzauberst.

Vanilla Werte:

* Lederrüstung: 15
* Kettenrüstung: 12
* Eisenrüstung: 9
* Goldrüstung: 25
* Diamantrüstung: 10
* Netheriterüstung: 15