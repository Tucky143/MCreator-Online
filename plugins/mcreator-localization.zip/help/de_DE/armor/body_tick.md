Wenn eine Entität die Body/Brustplatte ausgerüstet hat, wird die Prozedur jeden Tick durchgeführt.

Übergebene Entität ist die Entität die die Rüstung trägt, der übergebene Gegenstandstapel ist der Gegenstand der Rüstung.