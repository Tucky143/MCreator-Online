Pflanzentypen bestimmen, wo eine Pflanze von Spielern und während der Weltgeneration platziert werden kann. Denken Sie daran, dass statische Pflanzen immer auf (Grobe) Erde bleiben können, Podzol, Gras und Ackerland, während anbaubare Pflanzen immer auf sich selbst bleiben können.

Die vollständige Pflanzentypliste [finden Sie hier](https://mcreator.net/wiki/plant-types-list).