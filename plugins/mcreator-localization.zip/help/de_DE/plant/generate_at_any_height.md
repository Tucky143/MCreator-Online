Aktivieren Sie diese Option, um diese Pflanze in jeder Höhe zu generieren, anstatt auf der Weltfläche.

Diese Option sollte für Pflanzen aktiviert werden, die im Nether generieren.