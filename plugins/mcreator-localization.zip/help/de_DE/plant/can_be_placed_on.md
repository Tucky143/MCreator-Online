Liste der Blöcke, auf denen die Pflanze platziert werden kann.

HINWEIS: Überschreibt den Zustand der Platzierung des Pflanzentyps.