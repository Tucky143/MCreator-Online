Dieser Parameter legt fest, wie viele Male pro Chunk-Pflanzenstopp generiert wird.

Pflanzen werden nicht einzeln erzeugt, sondern in Flecken.

Zum Beispiel bedeutet das Setzen dieses Wertes auf 1 nicht, dass es in jedem Chunk nur eine Pflanze gibt; stattdessen wird jeder Chunk (höchsten) einen Cluster dieser Pflanzen haben.

Daher reicht das Setzen dieses Wertes auf einen niedrigen Wert (4 oder weniger) für die meisten Zwecke aus.