Aktivieren Sie diese Option, um Ihre Pflanze in einer Kachel-Einheit zu wechseln.

Du kannst Daten (wie NBT Tags) in deiner Anlage speichern, wenn dies aktiviert ist.

Aktivieren Sie diese Option nicht, wenn sie nicht wirklich aus Performance-Gründen benötigt wird.