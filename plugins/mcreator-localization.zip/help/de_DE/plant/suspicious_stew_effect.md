Dieser Parameter bestimmt die Trankwirkung der verdächtigen Eintöpfe, die mit dieser Pflanze hergestellt werden.

HINWEIS: Du musst die Pflanze zum `Minecraft:small_flowers` Item Tag hinzufügen, um verdächtige Eintöpfe herstellen zu können.