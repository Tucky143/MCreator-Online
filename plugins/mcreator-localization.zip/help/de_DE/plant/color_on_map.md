Dieser Parameter regelt, wie die Pflanze auf den Karten angezeigt wird.

Wenn es auf Standard gesetzt ist, wird die Farbe FOLIAGE sein.