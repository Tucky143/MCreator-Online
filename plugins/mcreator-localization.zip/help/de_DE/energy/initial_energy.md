Legen Sie den Standardwert des Energie-Elements fest (Block, Element, ...).

Dies ist die Energie, die dein Element haben wird, wenn ein Spieler es in der Welt platziert das Element ist natürlich gespawnt oder erscheint in der Welt).