Aktivieren Sie diese Option, um die Speicherung von Energie zu aktivieren.

Blöcke müssen die Kacheleinheit aktiviert haben, damit das Energiesystem richtig funktioniert.