Klicken Sie auf die Dropdown-Liste und wählen Sie die "Kategorie" der Beutetabelle aus. Sie definiert nicht den Beutetabellentyp.

Es ist nur um Beutetabellennamen zu standardisieren. Benutze zum Beispiel Blöcke/Registry_name um Beutetabellen zu blockieren.