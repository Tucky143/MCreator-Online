Dieses Feld gibt eine Schätzung an, wie viel von der Oberfläche der Welt von diesem Biom abgedeckt wäre. Funktioniert nur dann richtig, wenn die Werte für Biome zwischen -1 und 1 liegen, da dieses der Bereich ist, der für Oberweltbiome verwendet wird.

Falls dein Biom in Nether- oder Oberwelthöhlen verwendet wird, ist diese Schätzung nicht gültig.

Wenn Biome in einer benutzerdefinierten Dimension verwendet werden, hängt die Abdeckung von der Menge an Biomen ab, die diese Dimension hat und Biom-Generationsparameter von Biomen in der Dimension.