Die Wahrscheinlichkeit, Partikel zu spawnen.

HINWEIS: Dieser Wert wird durch 100 im Code geteilt.