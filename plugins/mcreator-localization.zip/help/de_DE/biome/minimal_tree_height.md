Dieser Parameter legt die minimale Höhe des Baumstammes fest, wenn er generiert wird.

Wird nur angewendet, wenn eine benutzerdefinierte Baumdefinition ausgewählt ist.