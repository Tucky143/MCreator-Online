Biome mit ähnlicher Verrücktheit werden enger zusammen generieren und beim Generieren um den gleichen Ort in der Welt konkurrieren. Zu ähnliche Werte führen dazu, dass einige Biome nicht erzeugt werden.

Während Werte von -2 bis 2 gültig sind, verwenden Vanillebiome nur Werte im Bereich von -1 bis 1.