Wähle diese Einstellung, um Ozeanruinen in deinem Biom zu haben.
* NONE: Es werden keine Ruinen aus dem Meer erzeugt.
* COLD: Ozeanruinen aus Stein werden generiert
* WARM: Ozeanruinen aus Sandstein werden generiert