Erosion bestimmt, wie erodiert das Terrain ist. Kleinere Werte beschreiben Biome, die normalerweise in flacheren Weltregionen erzeugt.

Biome mit ähnlicher Erosion werden näher zusammen generieren und beim Generieren um den gleichen Ort in der Welt konkurrieren. Zu ähnliche Werte führen dazu, dass einige Biome nicht erzeugt werden.

Während Werte von -2 bis 2 gültig sind, verwenden Vanillebiome nur Werte im Bereich von -1 bis 1.

Verschiedene Overworld Vanilla-Biome nutzen diese Wertebereiche:

* -1,0 bis -0,78
* -0,78 bis -0.375
* -0.375 bis -0.2225
* -0.2225 bis 0.05
* 0.05 bis 0.45
* 0.45 bis 0.5
* 0.55 bis 1.0