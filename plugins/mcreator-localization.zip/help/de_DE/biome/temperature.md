Dieser Parameter steuert die Klimatemperatur des Bioms.

0.0 ist wie die Snowy Tundra und 2.0 ist wie die Wüste.

* Werte unter 0,15 machen beim Niederschlag benutzerdefinierten Biomschnee
* Werte zwischen 0,15 und 1,5 lassen es im Biom regnen
* Werte größer als 1,5 werden das Biom trocken machen (Deaktiviere Regen in Wüsten zum Beispiel)