Dieser Parameter steuert den Block, der für Obst wie die Kakaobohnen mit den Dschungelbäumen verwendet wird, falls benutzerdefinierte Bäume aktiviert sind.

Wählen Sie Luftblock, um Baumfrüchte zu deaktivieren.