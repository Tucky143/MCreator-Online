Standardfunktionen sind vorkonfigurierte Funktionen (Minecraft-Funktionen), die du in deinem Biom verwenden kannst.
