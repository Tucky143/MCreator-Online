Dieser Parameter steuert die Farbe des Grases in diesem Biom.

Dieser Parameter ändert auch die Farbe anderer Pflanzen (Laub).