Wähle die Entitäten aus, die auf natürliche Weise in deinem Biom spawnen sollen.

Wählen Sie nur passive oder feindliche Mobs. Wähle hier nicht den Spieler oder spezielle Entitäten aus, da dies die Welt zum Absturz bringen könnte, wenn du versuchst, solche Entitäten zu spawnen.