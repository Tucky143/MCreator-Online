Dieser Parameter steuert den Block, der benutzt wird, um Ranken zu ersetzen.

Wählen Sie einen Luft-Block, um Ranken zu verhindern.
