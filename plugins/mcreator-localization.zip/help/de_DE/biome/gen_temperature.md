Dieser Parameter steuert die Biomerzeugung und nicht das Klima.

Biome mit ähnlicher Temperatur werden enger zusammen mit erzeugt und werden beim Generieren um den gleichen Ort in der Welt konkurrieren. Zu ähnliche Werte führen dazu, dass einige Biome nicht erzeugt werden.

Während Werte von -2 bis 2 gültig sind, verwenden Vanillebiome nur Werte im Bereich von -1 bis 1.

Verschiedene Overworld Vanilla-Biome nutzen diese Wertebereiche:

* -1.0 bis -0.45
* -0.45 bis -0.15
* -0.15 bis 0.2
* 0.2 bis 0.55
* 0.5 bis 1.0