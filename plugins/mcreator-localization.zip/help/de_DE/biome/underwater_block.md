Dieser Parameter legt die Blöcke, die unter Wasser generiert werden, fest. Die meisten Vanilla-Biome nutzen Erde oder Kies dafür.

Versuchen Sie komplexe Blöcke zu vermeiden, z. B.:

* Transparente Blöcke
* Blöcke, die keine vollen Würfel sind
* Blöcke mit "Tile entitiy", NBT-Tags oder eigenem Inventar
* Blöcke, die als Zielpunkt verwendet werden
* Blöcke, die ticken

Wenn Sie solche Blöcke verwenden, wird die Weltgeneration langsam sein und in der geladenen Welt kann es starke Verzögerungen geben.