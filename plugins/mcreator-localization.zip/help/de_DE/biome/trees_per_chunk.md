Dieser Parameter steuert die Anzahl der Bäume (der Typ, den Sie ausgewählt haben) pro Biom-Chunk.

Auf 0 setzen, um Bäume zu deaktivieren.