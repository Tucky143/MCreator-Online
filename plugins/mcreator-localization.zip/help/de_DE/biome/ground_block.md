Dieser Parameter steuert den Block auf der oberen Ebene des Bioms.

In der Regel wird hier Vanille oder benutzerdefiniertes Gras für die meisten Biome verwendet.

Dieser Block soll in minecraft:dirt<0> Block-tags damit Pflanzen und Bäume richtig in der Welt spawnen.</p>

<p spaces-before="0">Versuche keine komplexen Blöcke zu nutzen, wie:</p>

<ul>
<li>durchsichtige Blöcke</li>
<li>blöcke die kein voller Block sind</li>
<li>blöcke mit tile entity, NBT-Tags oder Inventar</li>
<li>blöcke die als POI benutzt werden</li>
<li>blöcke mit Tick</li>
</ul>

<p spaces-before="0">Wenn du solche Blöcke benutzt, word die Weltgeneration langsam sein und die geladene Welt wird sehr viel laggen.</p>