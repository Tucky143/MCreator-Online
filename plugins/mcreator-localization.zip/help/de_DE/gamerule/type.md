Dies ist der Spielregel-Typ. Sie müssen den besten Typ je nach Plan(en) auswählen
* Anzahl bedeutet, dass die Spielregel nur in eine Zahl (ganze Zahl) geändert werden kann
* Logik bedeutet, dass die Spielregel nur boolesch sein kann (wahr oder falsch)