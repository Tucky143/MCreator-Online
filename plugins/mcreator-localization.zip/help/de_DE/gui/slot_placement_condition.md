Wenn die Bedingung wahr ist, werden die Spieler nicht in der Lage sein, die Gegenstände auf diesem Platz zu platzieren. aber sie werden trotzdem Gegenstände ohne Einschränkungen nehmen können.

Hinweis: Diese Bedingung überschreibt den Parameter "Limit Stack Input".