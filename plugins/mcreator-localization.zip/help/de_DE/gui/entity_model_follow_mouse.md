Wenn aktiviert, dreht sich das angezeigte Entitätsmodell auf die Position der Maus.

Die Mausrotation wird dem bestehenden festen Rotationswert hinzugefügt.