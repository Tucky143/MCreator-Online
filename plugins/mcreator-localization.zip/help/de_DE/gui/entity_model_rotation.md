Entity Yaw-Rotation Parameter definiert die ursprüngliche Rotation des gerenderten Entitätsmodells in Grad.

Größere Werte können aufgrund der Einschränkungen der Rendering-Engine einige Rendering-Probleme verursachen.