Der Spieler muss mindestens diese Berechtigungsstufe haben, um den Befehl auszuführen.

Du kannst die Berechtigungsstufe auch deaktivieren. In diesem Fall funktioniert der Befehl auch, wenn Cheats in einer bestimmten Welt ausgeschaltet sind.

1 ist die einfachste Berechtigungsstufe und 4 ist die höchste (Server-OP-Stufe).

Schau auf [dieser Seite](https://mcreator.net/wiki/command-permission-levels) nach, welcher Befehl mit welcher Berechtigungsstufe ausgeführt werden kann.