Dieser Parameter legt fest, wie dieses Partikel dargestellt werden soll:

* **Opaque:** Transparent ohne Mipmapping (ähnlich wie Todespartikel)
* **Durchsichtig:** Teilweise transparent und die schwerste Ressourcen-Option (ähnlich den Partikel des Trank Effekts)
