Dieser Parameter steuert die anfängliche Drehgeschwindigkeit des Partikels. Negative Werte bedeuten eine Gegen-Uhr-Rotation.

Ein Wert von 0.314 ist ungefähr der gleiche Wert wie 1 Drehung pro Sekunde.