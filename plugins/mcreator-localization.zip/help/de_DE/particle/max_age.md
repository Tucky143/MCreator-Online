Das Partikel wird ablaufen, sobald sein Alter dieser Anzahl von Ticks entspricht.

Dies kann früher oder später geschehen, wenn die Altersdifferenz größer als 0 ist.
