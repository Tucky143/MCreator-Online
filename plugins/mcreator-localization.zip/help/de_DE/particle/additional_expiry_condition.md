Das Partikel verfällt vor seinem maximalen Alter, wenn es die ausgewählte Bedingung übergeht.

Wenn keine Bedingung definiert ist, kann Partikel nur ablaufen, wenn es das maximale Alter in Ticks erreicht.