Wenn die Textur eine gefliesene Textur ist (mehrere Texturen in einem vertikalen Streifen), die Textur wird zufällig aus einer der möglichen Kacheln im Streifen ausgewählt.

Wenn die animierte Textur aktiviert ist, wird die Partikel in der Reihenfolge der Texturfliesen animiert.

WICHTIG: Wenn sich der Name der Textur vom Registry-Namen des Elements unterscheidet, wird eine Kopie der Textur erstellt.