Mit diesem Parameter legst du die abzuspielende Animation fest.

Animationen funktionieren mit jedem Modell, aber nur Modelle, die die gleichen Namen haben wie die Teile der Animation, werden animiert.

Wenn für das Modell bereits grundlegende Animationen auf Modellebene festgelegt sind, werden diese Animationen angewendet, **nachdem** alle hier aufgeführten Animationen angewendet wurden.
Wir empfehlen, nur das eine oder das andere Animationssystem zu verwenden, nicht beide für dasselbe Modell.