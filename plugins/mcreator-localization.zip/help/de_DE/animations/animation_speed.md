Dieser Parameter bestimmt, wie schnell die Animation abgespielt wird.

Wenn du dies auf 1 einstellst, wird die Animation mit der Geschwindigkeit abspielen, die sie
für die Wiedergabe in der Zeitleiste entwickelt hat.

Höhere Werte als 1 sorgen dafür, dass die Animation schneller abgespielt wird, während die Werte unter 1 die Animation langsamer abspielen.

Wert 0 lässt die Animation überhaupt nicht abspielen.