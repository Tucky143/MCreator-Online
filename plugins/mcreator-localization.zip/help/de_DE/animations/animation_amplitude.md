Dieser Parameter bestimmt, wie stark der Animationseffekt ist.

Verwende 1 für die gleiche Anzahl von Drehungen und Übersetzungen wie die Definition der Animation selbst.

Dieser Parameter funktioniert nur mit Lauf-Animationen.