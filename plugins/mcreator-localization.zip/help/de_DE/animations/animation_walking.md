Wenn aktiviert, ist diese Animation nicht als "Action"-Animation gedacht, sondern eher als
Standard-Laufanimation mit dem Walking-Controller der Kreatur.

Die Keyframe-Progression wird durch den Vanilla-Laufcontroller des
ausgewählten Kreaturentyps gesteuert.

Du kannst weiterhin zusätzliche Bedingungen für die Animation anwenden, die kontrolliert, wann die Animation angewendet wird.