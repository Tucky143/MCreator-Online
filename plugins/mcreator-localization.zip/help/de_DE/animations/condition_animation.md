Wenn diese Prozedur wahr ist, wird die Wiedergabe der Animation gestartet, sofern die Animation nicht bereits abgespielt wird.

Wenn diese Prozedur falsch zurückgibt, wird die Wiedergabe der Animation beendet.

Wenn der Schalter zu schnell läuft, gibt es möglicherweise nicht genug Zeit, um die Animation zu starten oder die Wiedergabe zum Neustart zu starten.

Wenn die Animation nicht auf Schleife gesetzt ist, es wird gestoppt, wenn es das Ende der Animation erreicht hat und die Bedingung muss von true to false und zurück nach true umschalten, um die Animation neu zu starten.

Bei Laufanimationen steuert dieser Parameter die Wiedergabe der Animation.