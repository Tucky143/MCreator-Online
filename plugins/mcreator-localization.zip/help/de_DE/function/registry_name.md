Sie können Ihren Funktionsnamen in einem Wort oder mit mehreren Wörtern mit Unterstrichen(n) eingeben.

Beispiele:
* errungenschaft
* advancement_biome_belohnung