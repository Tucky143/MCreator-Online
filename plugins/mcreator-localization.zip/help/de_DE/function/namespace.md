* **Modus:** Wird nur für deine Mod verwendet (so eine Funktion wie `${modid}:${registryname}`)

* **Minecraft:** Wird mit einigen Minecraft-Optionen verwendet (so eine Funktion wie `Minecraft:${registryname}`)