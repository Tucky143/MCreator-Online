Dieser Wert wird mit der Stufe der Verzauberung (welche der Gegenstand derzeit hat) multipliziert, um die Anzahl des Schadens zu erhalten, den deine Verzauberung schützen wird.

Zum Beispiel hat PROTECTION einen Wert von 1, also für die erste Ebene die Verzauberung wird den Spieler von 1 Schadenspunkt als 1 (Level) * 1 (deinen Wert) = 1 schützen.