This determines how often your biome will generate in the end.
All vanilla end biomes have a weight of 1. 
Setting this value too high will cause your biome to completely take over the end.