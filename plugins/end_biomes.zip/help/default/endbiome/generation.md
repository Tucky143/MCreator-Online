This determines what type of terrain the biome will generate.
The generation will be the same as vanilla end biomes, it is up to you to customize it with structures and features.