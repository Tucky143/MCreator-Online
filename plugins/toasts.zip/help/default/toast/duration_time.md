This is the amount of milliseconds (1000ms = 1s) the toast will be displayed for if no custom amount is set when showing this toast.
Once the time is reached, the toast will be removed.