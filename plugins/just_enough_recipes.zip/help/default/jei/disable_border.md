If this parameter is enabled, JEI will not render its own border in your recipe preview.
Only enable this if you plan to draw your own border around your texture.