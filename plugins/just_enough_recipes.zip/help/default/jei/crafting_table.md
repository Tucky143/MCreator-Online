These are the crafting tables that can be used to make the recipes you will include in this category. 
By registering it here, users will be able to find the recipes the tables craft in JEI by hovering over them
in their inventory and clicking U.