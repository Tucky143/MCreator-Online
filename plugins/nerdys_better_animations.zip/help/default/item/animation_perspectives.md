This parameter determines which perspectives java animations will play in.
You can use this to limit animations to only play in first person or third person.