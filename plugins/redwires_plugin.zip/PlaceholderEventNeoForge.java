import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.ICancellableEvent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.Direction;
import java.util.Map;
import java.util.HashMap;
import javax.annotation.Nullable;

/*	This event does nothing on its own and exists purely for custom-coding purposes
 * 	(If you're like me and want to use the procedure Blockly UI)
 * 	A builder class is included to easily create a PlaceholderEvent without defining every parameter manually
 * 	
 * 	Example usage:
 * 	PlaceholderEvent.builder()
 * 	.entity(entity)
 * 	.level(level)
 * 	.build(); //returns a PlaceholderEvent with only entity and level defined.
 * 	
 * 	To add this to your workspace:
 * 	1. Create a Custom Element with the name "PlaceholderEvent"
 * 	2. Replace everything *EXCEPT FOR THE PACKAGE NAME* with the contents of this file
 * 	
 * 	Note:
 * 	This specific file works with NeoForge as it uses ICancellableEvent and neoforged imports
 * 	For the Forge version of this class, refer to the "PlaceholderEventForge.java" file
 */

public class PlaceholderEvent<T> extends Event implements ICancellableEvent {
	private boolean canceled;
	
	@Nullable public final Entity entity;
	@Nullable public final Entity sourceEntity;
	@Nullable public final Entity immediateSourceEntity;
	@Nullable public final Level level;
	@Nullable public final Vec3 pos;
	@Nullable public final ItemStack itemStack;
	@Nullable public final BlockState blockState;
	@Nullable private final Runnable onCancel;
	@Nullable public final DamageSource damageSource;
	@Nullable public final ResourceKey<Level> dimension;
	@Nullable public final Direction direction;
	@Nullable public final Map<String, T> extras;

	public PlaceholderEvent(Entity entity, Entity sourceEntity, Entity immediateSourceEntity, Level level, Vec3 pos, ItemStack itemStack, BlockState blockState,
	Runnable onCancel, DamageSource damageSource, ResourceKey<Level> dimension, Direction direction, Map<String, T> extras) {
		this.entity = entity;
		this.sourceEntity = sourceEntity;
		this.immediateSourceEntity = immediateSourceEntity;
		this.level = level;
		this.pos = pos;
		this.itemStack = itemStack;
		this.blockState = blockState;
		this.onCancel = onCancel;
		this.damageSource = damageSource;
		this.dimension = dimension;
		this.direction = direction;
		this.extras = extras;
	}

	public static <T> Builder<T> builder() {
		return new Builder<>();
	}

	@Override
	public boolean isCanceled() { return canceled; }
	
	@Override
	public void setCanceled(boolean canceled) {
		if (canceled && !this.canceled) {
			this.canceled = true;
			if (onCancel != null) {
				onCancel.run(); //runs only once when canceled
			}
		}
	}

	public static final class Builder<T> {
		private Entity entity;
		private Entity sourceEntity;
		private Entity immediateSourceEntity;
		private Level level;
		private Vec3 pos;
		private ItemStack itemStack;
		private BlockState blockState;
		private Runnable onCancel;
		private DamageSource damageSource;
		private ResourceKey<Level> dimension;
		private Direction direction;
		private Map<String, T> extras;

		public Builder<T> entity(Entity e) {
			this.entity = e;
			return this;
		}

		public Builder<T> sourceEntity(Entity e) {
			this.sourceEntity = e;
			return this;
		}

		public Builder<T> immediateSourceEntity(Entity e) {
			this.immediateSourceEntity = e;
			return this;
		}

		public Builder<T> level(Level l) {
			this.level = l;
			return this;
		}

		public Builder<T> pos(Vec3 v) {
			this.pos = v;
			return this;
		}

		public Builder<T> itemStack(ItemStack i) {
			this.itemStack = i;
			return this;
		}

		public Builder<T> blockState(BlockState b) {
			this.blockState = b;
			return this;
		}

		public Builder<T> onCancel(Runnable r) {
			this.onCancel = r;
			return this;
		}

		public Builder<T> damageSource(DamageSource d) {
			this.damageSource = d;
			return this;
		}

		public Builder<T> dimension(ResourceKey<Level> d) {
			this.dimension = d;
			return this;
		}

		public Builder<T> direction(Direction d) {
			this.direction = d;
			return this;
		}

		public Builder<T> extras(Map<String, T> e) {
			this.extras = e;
			return this;
		}

		public PlaceholderEvent<T> build() {
			return new PlaceholderEvent(entity, sourceEntity, immediateSourceEntity, level, pos, itemStack, blockState, onCancel, damageSource, dimension, direction, extras);
		}
	}
}