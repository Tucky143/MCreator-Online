This parameter controls in what order your custom slot is added to the curios inventory.
Lower numbers make it get added earlier, and bigger numbers make it get added later.