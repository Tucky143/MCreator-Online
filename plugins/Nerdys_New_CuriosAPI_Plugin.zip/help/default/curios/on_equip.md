This procedure executes once after the bauble is equipped in a curios slot. This also executes
when loading into a world with the bauble already equipped.